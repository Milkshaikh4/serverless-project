/* eslint-env mocha */

const mochaPlugin = require('serverless-mocha-plugin');
const dirtyChai = require('dirty-chai');

mochaPlugin.chai.use(dirtyChai);
const { expect } = mochaPlugin.chai;
const wrapped = mochaPlugin.getWrapper('createPost', '../../api/createPost.js', 'createPost');

describe('exampleFunction', () => {
  before((done) => {
    done();
  });

  it('implement tests here', () => wrapped.run({}).then((response) => {
    expect(response).to.not.be.empty();
  }));
});
