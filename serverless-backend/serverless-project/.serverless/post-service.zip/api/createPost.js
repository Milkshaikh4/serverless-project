/* eslint-disable no-console */
const middy = require('@middy/core');
const cors = require('@middy/http-cors');
const httpErrorHandler = require('@middy/http-error-handler');

const uuid = require('uuid');
const AWS = require('aws-sdk');

AWS.config.setPromisesDependency(require('bluebird'));

const db = new AWS.DynamoDB.DocumentClient();

module.exports.createPost = middy((event) => {
  const { descr, img } = JSON.parse(event.body);

  if (typeof descr !== 'string' || typeof img !== 'string') {
    return new Error("Couldn't submit post because of validation errors.");
  }

  const success = (props) => ({
    statusCode: 200,
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      message: 'Successfully created post',
      ...props,
    }),
  });

  return submitPost(post(descr, img)).then((res) => success(res.id));
}).use(httpErrorHandler()).use(cors());

const submitPost = (post) => {
  const payload = {
    TableName: process.env.POST_TABLE,
    Item: post,
  };

  console.log({
    message: 'pushing post to db',
    payload,
  });

  return db
    .putItem(payload)
    .promise()
    .then(() => post);
};

const post = (descr, img) => {
  const timestamp = new Date().getTime();
  return {
    id: uuid.v1(),
    descr,
    img,
    createdAt: timestamp,
    updatedAt: timestamp,
  };
};
