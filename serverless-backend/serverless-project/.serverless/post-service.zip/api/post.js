/* eslint-disable no-console */
const middy = require('@middy/core');
const cors = require('@middy/http-cors');
const httpErrorHandler = require('@middy/http-error-handler');

const uuid = require('uuid');
const AWS = require('aws-sdk');

AWS.config.setPromisesDependency(require('bluebird'));

const db = new AWS.DynamoDB.DocumentClient();

const create = middy((event) => {
  const { descr, img } = JSON.parse(event.body);

  if (typeof descr !== 'string' || typeof img !== 'string') {
    return new Error("Couldn't submit post because of validation errors.");
  }

  const success = (props) => ({
    statusCode: 200,
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      message: 'Successfully created post',
      ...props,
    }),
  });

  // const error = (err) => ({
  //   statusCode: 500,
  //   headers: {
  //     'Content-Type': 'application/json',
  //   },
  //   body: JSON.stringify({
  //     message: 'Unable to create post',
  //     err,
  //   }),
  // });

  return submitPost(post(descr, img)).then((res) => success(res.id));
});

create.use(httpErrorHandler()).use(cors());

const list = middy(() => {
  const params = {
    TableName: process.env.POST_TABLE,
  };

  console.log({
    message: 'getting posts from db',
    params,
  });

  const onScan = (err, data) => {
    if (err) {
      console.log({
        message: 'Error in getting posts',
        err,
      });
      return err;
    }

    return data.Items;
  };

  return db
    .scan(params, onScan)
    .promise()
    .then((posts) => ({
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        posts,
      }),
    }));
});

list.use(httpErrorHandler()).use(cors());

const deletePost = middy((event) => {
  const params = {
    TableName: process.env.POST_TABLE,
    key: {
      id: {
        S: event.pathParameters.id,
      },
    },
  };

  console.log({
    msg: 'deleting item',
    params,
  });

  const handleHook = (err, data) => {
    if (err) console.log(err, err.stack);
    else console.log(data);
  };

  return db.deleteItem(params, handleHook).promise();
});

deletePost.use(httpErrorHandler()).use(cors());

const submitPost = (post) => {
  const payload = {
    TableName: process.env.POST_TABLE,
    Item: post,
  };

  console.log({
    message: 'pushing post to db',
    payload,
  });

  return db
    .putItem(payload)
    .promise()
    .then(() => post);
};

const post = (descr, img) => {
  const timestamp = new Date().getTime();
  return {
    id: uuid.v1(),
    descr,
    img,
    createdAt: timestamp,
    updatedAt: timestamp,
  };
};

module.exports = { create, list, deletePost };
