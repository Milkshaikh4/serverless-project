
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'nabilshaikhnabil',
  applicationName: 'serverless-project-app',
  appUid: 'QWWF1KY68rJqMfT7p2',
  orgUid: 'df305377-fd20-41fd-ab92-5f90ae7d5f8a',
  deploymentUid: '06706855-318e-4fae-a4e8-76ccd46dd874',
  serviceName: 'post-service',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'post-service-dev-listPosts', timeout: 6 };

try {
  const userHandler = require('./api/post.js');
  module.exports.handler = serverlessSDK.handler(userHandler.list, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}